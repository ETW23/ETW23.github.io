public class Rectangulo implements Medible {
  private float base;
  private float altura;
 
  public Rectangulo (float base, float altura) {
	this.base=base;
	this.altura=altura;
  }

  // resto de métodos de la clase Rectangulo

  public float area() { 
    return (base*altura); 
  } 
  public float perimetro() { 
    return (2*base+2*altura);
  } 
}
