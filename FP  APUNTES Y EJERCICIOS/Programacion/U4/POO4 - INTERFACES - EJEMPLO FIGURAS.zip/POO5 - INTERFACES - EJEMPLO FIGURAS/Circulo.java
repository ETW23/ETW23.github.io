public class Circulo implements Medible {
  private float radio;

  public Circulo (float radio){
    this.radio=radio;
  }  
  
   // resto de métodos de la clase Circulo

  public float area() { 
    return (PI*(float)Math.pow(radio,2)); 
  } 
  public float perimetro() { 
    return 2*PI*radio; 
  } 
}

