

public class Cuadrado implements Medible
{
   private float lado;
   
   public Cuadrado (float lado){
     this.lado=lado;
   }  
   //  resto de métodos de la clase Cuadrado

   public float area() { 
      return lado*lado; 
   } 
   public float perimetro() { 
      return lado*4; 
   } 

}
