import java.awt.*;

public class Cuadrado extends Figura
{
    private int lado;
   
    public Cuadrado(int xPos, int yPos, String color, int lado)
    {
        super(xPos,yPos,color);
        this.lado = lado;
    }
    
     /**
     * El resto de métodos, la clase "hija"  Cuadrado los hereda directamente de la clase Figura
     * 
     * Lo que hay que "personalizar" en la clase Cuadrado son los métodos que dependen del lado, que es un atributo específico de la clase Cuadrado
     * 
     * cambiaTamaño()  y dibujar()
     * 
     * OBSERVAR como podemos acceder al atributo lado directamente, al ser private de la clase Cuadrado, pero no podemos acceder a los atributos xPos, yPos, color y visible
     * porque son private de la clase "padre". No hay problema, para eso usamos los métodos GET correspondientes que son public. La encapsulación está bien definida
     */
    
    public void cambiaTamaño(int nuevoLado)
    {
        borrar();
        lado = nuevoLado;
        dibujar();
    }
    
    @Override
    public void dibujar()
    {
        if(getVisible()) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, getColor(), new Rectangle(getXPos(), getYPos(), lado, lado));
            canvas.wait(10);
        }
    }
    
}   
