
import java.awt.geom.*;

public class Circulo extends Figura
{
    private int diametro;
    
    public Circulo(int xPos, int yPos, String color, int diametro)
    {
       super(xPos,yPos,color);
       this.diametro = diametro;
    }
    
    /**
     * El resto de métodos de la clase Figura los hereda directamente la clase Círculo
     * 
     * Lo que hay que "personalizar" en la clase círculo son los métodos que dependen del diámetro, que es un atributo específico de la clase círculo
     * 
     * cambiarTamaño()  y dibujar()
     * 
     * OBSERVAR como podemos acceder al atributo diametro directamente al ser private de la clase círculo, pero no podemos acceder a los atributos xPos, yPos, color y visible
     * porque son private de la clase "padre". No hay problema, para eso usamos los métodos GET correspondientes que son public. La encapsulación está bien definida
     */
    
    public void cambiaTamaño(int nuevoDiametro)
    {
        borrar();
        diametro = nuevoDiametro;
        dibujar();
    }
    
    @Override
    public void dibujar()
    {
        if(getVisible()) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, getColor(), new Ellipse2D.Double(getXPos(), getYPos(), diametro, diametro));
            canvas.wait(10);
        }
    }

    
}
