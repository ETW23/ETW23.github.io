import java.awt.*;
import java.awt.geom.*;

/**
 * OPTIMIZAMOS EL EJERCICIO INICIAL CREANDO UNA CLASE "PADRE" "Figura". Las clases "Circulo" "Cuadrado" "Rectángulo"(NUEVA) y "Triangulo" heredan de "Figuras" 
 * 
 * Tan sólo necesitamos escribir en cada clase el método "cambiaTamaño()" para adaptarlo a cada figura geométrica. Todos los demás métodos relativos al 
 * color, posición y desplazamientos de cada figura geométrica se definen y heredan de la clase "Figuras" pues son atributos y comportamientos comunes.
 * 
 * SE HAN RESUMIDO Y MEJORADO LOS METODOS PARA DESPLAZAMIENTO VERTICAL-HORIZONTAL. También los GETTERS (AL MENOS) PARA LAS CONSULTAS DE ATRIBUTOS desde
 * las clases "Hijas"
 * 
 * El caso de los métodos "dibujar() - borrar()" ES ESPECIAL. para poder llevarlos a cabo llamamos a la clase Canvas, y como se ve en los métodos de desplazamiento
 * o cambios en una figura, en muchos casos 1º se llama a borrar() - 2º se hacen los cambios - 3º se llama a dibujar()
 * 
 * Con borrar() no hay problema pues todas las figuras se borran igual llamando al método canvas.Erase() - podemos escribirlo en la clase "Figura" y heredarlo tal cuál 
 * 
 * dibujar() es distinto, pues a la hora de dibujar cada figura geométrica se dibuja distinto y hemos de hacer un dibujar() distinto para cada clase "hija". 
 * Podría ser éste un ejemplo de método ABSTRACTO que simplemente declaramos en la clase PADRE con "abstract dibujar();" para luego obligar a cada clase "hija" a implementarlo
 * 
 * ... pero en este caso me interesa más hacerlo normal, pero vacío. ¿por qué?. Si lo dejo abstracto cada vez que hagamos algun cambio en una figura tendremos que llamar a dibujar()
 * En este caso mejor lo dejo "a medias" y lo sobreescribo @Overrides en cada clase "hija". De esa forma en la clase "padre" despues de cada cambio llamo a dibujar() y el cambio
 * ya queda hecho (el objeto queda dibujado) en el método que sea, pues aunque dibujar() está vacío, la llamada no da error al estar @Override, y se ejecuta el método de la clase
 * "hija" que es lo que nos interesa.
 */

public class Figura
{
    private int xPos;
    private int yPos;
    private String color;
    private boolean visible;

    public Figura(int xPos, int yPos, String color)
    {
        this.xPos = xPos;
        this.yPos = yPos;
        this.color = color;
        visible = true;
    }
    public int getXPos()
    {
        return xPos;
    }
     public int getYPos()
    {
        return yPos;    
    }
    public String getColor()
    {
        return color;    
    }
     public boolean getVisible()
    {
        return visible;    
    }
    /**
     * hacer visible la figura
     */
    public void mostrar()
    {
        visible = true;
        dibujar();
    }

    /**
     * ocultar la figura
     */
    public void ocultar()
    {
        borrar();
        visible = false;
    }

    /**
     * mover la figura a la dcha.
     */
     
    public void moverDerecha(int pixels)
    {
        borrar();
        xPos += pixels;
        dibujar();
    }

    
    /**
     * mover la figura a la Izd.
     */
     
    public void moverIzquierda(int pixels)
    {
        borrar();
        xPos -= pixels;
        dibujar();
    }
    /**
     * mover la figura hacía Abajo
     */
    public void moverAbajo(int pixels)
    {
        borrar();
        yPos += pixels;
        dibujar();
    }
    /**
    * mover la figura hacía Arriba
    */
    public void moverArriba(int pixels)
    {
        borrar();
        yPos -= pixels;
        dibujar();
    }
    

    /**
     * mover la figura horizontalmente (lentamente) un número de pixels 
     */
    public void moverSuaveHorizontal(int pixels)
    {
        int delta;

        if(pixels < 0) 
        {
            delta = -1;
            pixels = -pixels;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < pixels; i++)
        {
            xPos += delta;
            dibujar();
        }
    }

    /**
     *  mover la figura verticalmente (lentamente) un número de pixels 
     */
    public void moverSuaveVertical(int pixels)
    {
        int delta;

        if(pixels < 0) 
        {
            delta = -1;
            pixels = -pixels;
        }
        else 
        {
            delta = 1;
        }

        for(int i = 0; i < pixels; i++)
        {
            yPos += delta;
            dibujar();
        }
    }

    /**
     * Cambiar el color a "rojo", "amarillo", "azul", "verde","magenta","negro".
     */
    public void cambiaColor(String nuevoColor)
    {
        color = nuevoColor;
        dibujar();
    }

       
    /*
     * Dibujar es un método que dependerá de cada tipo de figura geométrica, se SOBREESCRIBE @Overrides en cada clase
     */
    public void dibujar()
    {
    
    }
    

    /*
     * Borra el círculo
     */
    public void borrar()
    {
        if(visible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}
