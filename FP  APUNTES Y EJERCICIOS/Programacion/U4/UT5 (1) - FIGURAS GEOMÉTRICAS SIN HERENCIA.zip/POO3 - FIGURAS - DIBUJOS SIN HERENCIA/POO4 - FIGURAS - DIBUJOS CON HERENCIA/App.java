public class App
{
  public static void main (String[] args)
  {
    Cuadrado pared = new Cuadrado(50,50,"azul",100);
    Cuadrado ventana = new Cuadrado(200,200,"magenta",200);
    Triangulo tejado = new Triangulo(100,200,"rojo", 50,70);
    Circulo sol = new Circulo(100,100,"amarillo",100);
    Rectangulo campo= new Rectangulo(200,100,"verde",100,50);
    pared.dibujar();
    ventana.dibujar();
    tejado.dibujar();
    sol.dibujar();
    campo.dibujar();
      
  }

}