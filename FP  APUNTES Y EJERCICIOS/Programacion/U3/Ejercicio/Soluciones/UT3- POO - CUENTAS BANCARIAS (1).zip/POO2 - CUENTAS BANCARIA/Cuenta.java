
/**
 * Clase para modelar una sencilla cuenta bancaria con sólo 2 atributos:
 *      - titular
 *      - saldo
 *      
 * Los métodos que definen el comportamiento de una cuenta bancaria,
 * además del constructor, setters y getters son:
 * 
 *      - ingresar
 *      - reintegrar
 *      - toString
 * 
 * @author 
 * @version 1.0 Diciembre 2023
 */
public class Cuenta
{
    private String titular;
    private double saldo;
 
    public Cuenta(String titular) {                                 //CONSTRUCTOR SÓLO CON TITULAR
        this(titular, 0); 
    }

    public Cuenta(String titular, double saldo) {        //CONSTRUCTOR CON TITULAR E INGRESO INICIAL
        this.titular = titular;
        this.saldo = saldo;
    }
                                                             //SETTERS Y GETTERS
    public String getTitular() {
        return titular;
    }
    public void setTitular(String titular) {
        this.titular = titular;
    }
 
    public double getSaldo() {
        return saldo;
    }
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
                         //MÉTODOS DE COMPORTAMIENTO
    public void ingresar(double cantidad) {
        if(cantidad > 0){
            setSaldo(getSaldo() + cantidad);   
        }
    }
 
    public void reintegrar(double cantidad) {
        if (getSaldo() - cantidad < 0) {
            setSaldo(0);
        } else {
            setSaldo(getSaldo()- cantidad); 
        }
    }
    
    @Override
    public String toString() {
        return getTitular() + " tiene " + getSaldo() + " € en cuenta";
    }
}

