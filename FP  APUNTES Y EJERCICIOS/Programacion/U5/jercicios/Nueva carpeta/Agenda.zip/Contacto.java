/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.educastur.eduardocl.colecciones.agenda;
import java.io.Serializable;
import java.time.LocalDate;

public class Contacto implements Comparable <Contacto>, Serializable {
    private String nombre;
    private String telefono;
    private LocalDate cumple;

    public Contacto(String nombre, String telefono, LocalDate cumple) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.cumple = cumple;
    }

    public LocalDate getCumple() {
        return cumple;
    }

    public void setCumple(LocalDate cumple) {
        this.cumple = cumple;
    }

    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Contacto{" + "nombre=" + nombre + ", telefono=" + telefono + ", cumple=" + cumple + '}';
    }

    @Override
    public int compareTo(Contacto c) {
        return this.getNombre().compareTo(c.getNombre());
    } 
}
