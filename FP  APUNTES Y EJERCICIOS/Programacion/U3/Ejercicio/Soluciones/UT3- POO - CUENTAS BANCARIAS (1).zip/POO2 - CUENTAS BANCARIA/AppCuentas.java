public class AppCuentas
{
    public static void main(String[] args) {
         
    //INSTANCIAMOS 3 OBJETOS DE TIPO CUENTA – Usamos la SOBRECARGA DE CONSTRUCTORES
    Cuenta c01 = new Cuenta("Ana");
    Cuenta c02 = new Cuenta("Luisa", 1000);
    Cuenta c03 = new Cuenta("Víctor", 2000);
    
   //MOSTRAMOS LOS OBJETOS – Podemos hacerlo así, directamente, al haber codificado el método toString 
    System.out.println("\nDespués de instanciar los Objetos:\n");
    System.out.println(c01); 
    System.out.println(c02); 
    System.out.println(c03);
   
    //INGRESOS
    c01.ingresar(500);
    c02.ingresar(1000);
    c03.ingresar(2000);
    
    /*
     * En realidad no haría falta un método ingresar dentro de la clase cuenta, pues podemos acceder al atributo saldo a 
     * través de los SET/GET correspondientes
     * 
     * c01.setSaldo(c01.getSaldo()+500);
     * 
     */
    
   //MOSTRAMOS LOS OBJETOS
    System.out.println("\nDespués de hacer los Ingresos:\n");
    System.out.println(c01); 
    System.out.println(c02); 
    System.out.println(c03);
    
   //REINTEGROS
    c01.reintegrar(200);
    c02.reintegrar(500);
    c03.reintegrar(800);
    
    /*
     * Tampoco haría falta un método reintegrar dentro de la clase cuenta. Usando de nuevo los SET/GET correspondientes
     * 
     * c01.setSaldo(c01.getSaldo()-200);
     * 
     * VEREMOS COMO SIMPLIFICAMOS ESTA FORMA DE TRABAJAR EN LAS SIGUIENTES VERSIONES DE ESTA APLICACIÓN
     */

    //MOSTRAMOS LOS OBJETOS
    System.out.println("\nDespués de hacer los Reintegros:\n");
    System.out.println(c01); 
    System.out.println(c02); 
    System.out.println(c03);
   }
}
