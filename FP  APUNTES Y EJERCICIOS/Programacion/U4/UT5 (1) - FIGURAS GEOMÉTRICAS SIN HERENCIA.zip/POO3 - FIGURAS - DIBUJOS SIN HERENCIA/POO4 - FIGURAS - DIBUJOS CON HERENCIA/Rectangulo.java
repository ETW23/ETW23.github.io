import java.awt.*;

public class Rectangulo extends Figura
{
    private int base, altura;
   
    public Rectangulo (int xPos, int yPos, String color, int altura, int base)
    {
        super(xPos,yPos,color);
        this.altura=altura;
        this.base=base;
    }      
    
    
     /**
     * El resto de métodos, la clase "hija"  Rectangulo los hereda directamente de la clase Figura
     * 
     * Lo que hay que "personalizar" en la clase Rectangulo son los métodos que dependen del lado, que es un atributo específico de la clase Rectangulo
     * 
     * cambiaTamaño()  y dibujar()
     * 
     * OBSERVAR como podemos acceder al atributo lado directamente, al ser private de la clase Rectangulo, pero no podemos acceder a los atributos xPos, yPos, color y visible
     * porque son private de la clase "padre". No hay problema, para eso usamos los métodos GET correspondientes que son public. La encapsulación está bien definida
     */
    
    public void cambiaTamaño(int nuevaBase, int nuevaAltura)
    {
        borrar();
        base = nuevaBase;
        altura = nuevaAltura;
        dibujar();
    }
    
    @Override
    public void dibujar()
    {
        if(getVisible()) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, getColor(), new Rectangle(getXPos(), getYPos(), base, altura));
            canvas.wait(10);
        }
    }
    
}   
