   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.educastur.eduardocl.colecciones.agenda;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Eduardo
 */
public class Agenda {

    Scanner sc=new Scanner(System.in);
    private ArrayList<Contacto> agenda;

    public Agenda () {
        agenda= new ArrayList();
    }
    
    public static void main(String[] args) {
        
        Agenda a=new Agenda();
        a.importarAgenda();
        a.menu();
        a.persistirAgenda();
    }

    public void menu(){
               
        LocalDate hoy=LocalDate.now();
        
        
        
        int opcion=0;
        do{
            System.out.println("\n\n\n\n\n\t\t\t\tMENU DE OPCIONES\n");
            System.out.println("\t\t\t\t1 - NUEVO CONTACTO");
            System.out.println("\t\t\t\t2 - LISTA DE CONTACTOS");
            System.out.println("\t\t\t\t3 - MOSTRAR CONTACTO");
            System.out.println("\t\t\t\t4 - BORRAR CONTACTOS");
            System.out.println("\t\t\t\t5 - MODIFICAR CONTACTO");
            System.out.println("\t\t\t\t6 - LISTA DE CONTACTOS POR CUMPLE");
            System.out.println("\t\t\t\t9 - SALIR");
            opcion=sc.nextInt();
            switch (opcion){
                case 1:{
                    nuevoContacto();
                    break;
                }    
                case 2:{
                    listaContactos();
                    break;
                } 
                case 3:{
                    mostrarContacto();
                    break;
                } 
                case 4:{
                    borrarContacto();
                    break;
                } 
                case 5:{
                    modificarContacto();
                    break;
                } 
                case 6:{
                    listaCumples();
                    break;
                } 
            }
        }while (opcion != 9);
    }

    private void nuevoContacto() {
        sc.nextLine();
        System.out.println("ALTA DE NUEVO CONTACTO");
        System.out.println("NOMBRE:");
        String nombre=sc.nextLine().toUpperCase();
        String cumpleS, telefono;
        
        
        //Entrada Fecha contra expresión regular avanzada y conversión a LocalDate
        do{
            System.out.println("FECHA CUMPLE: (AÑO-MES-DÍA)");
            //SI QUEREMOS USAR OTRO FORMATO DE FECHA DISTINTO (Dia-mes-año) hay que usar un DateTimeFormatter
            cumpleS = sc.next();
        } while(!cumpleS.matches("(19|20)(((([02468][048])|([13579][26]))-02-29)|(\\d{2})-((02-((0[1-9])|1\\d|2[0-8]))|((((0[13456789])|1[012]))-((0[1-9])|((1|2)\\d)|30))|(((0[13578])|(1[02]))-31)))"));      
              
        LocalDate cumpleD = LocalDate.parse(cumpleS); //Fecha validada la convertimos a LocalDate
        
        //Entrada telefono contra Expresión regular
        do{
            System.out.println("TELEFONO:");
            telefono=sc.next();
        }while(!telefono.matches("[6-7][0-9]{8}")); 
        agenda.add(new Contacto(nombre,telefono,cumpleD));
        //MANTENEMOS LA AGENDA ORDENADA ALFABÉTICAMENTE - Contacto IMPLEMENTS Comparable para "incrustar" ese criterio
       Collections.sort(agenda);
    }

    private void listaContactos() {
        
        for (Contacto c:agenda){
            System.out.println(c); 
        }
    }

    private void listaCumples() {
        agenda.stream().sorted(Comparator.comparing(Contacto::getCumple)).forEach(System.out::println);
        
            /* Collections.sort(agenda, new ComparaContactosPorCumple());
            for (Contacto c:agenda){
            System.out.println(c);
            }*/
        
    }
    
    private void mostrarContacto() {
        sc.nextLine();
        System.out.println("\nNOMBRE PARA BUSCAR EN LA AGENDA? (RETURN PARA SALIR) ");
        String nombre=sc.nextLine();
        while(nombre.length()>0 ){
            try{
                int busca=buscaNombre(nombre); 
                System.out.println("\n" + agenda.get(busca));
            }catch (ContactoNoEncontrado e){
                System.out.println(e.getMessage());
            }
            System.out.println("\nNOMBRE PARA BUSCAR EN LA AGENDA? (RETURN PARA SALIR) ");
            nombre=sc.nextLine();
        }
    }

    private void borrarContacto() {
        sc.nextLine();
        System.out.println("\nNOMBRE PARA BORRAR DE LA AGENDA? (RETURN PARA SALIR) ");
        String nombre=sc.nextLine();
        while(nombre.length()>0 ){
            try{
              agenda.remove(buscaNombre(nombre)); 
              System.out.println("\nCONTACTO BORRADO ");
            }catch (ContactoNoEncontrado e){
              System.out.println(e.getMessage());
            }
            System.out.println("\nNOMBRE PARA BORRAR DE LA AGENDA? (RETURN PARA SALIR) ");
            nombre=sc.nextLine();
        }
    }
    
    private void modificarContacto() {
        sc.nextLine();
        System.out.println("\nNOMBRE PARA MODIFICAR TELEFONO? ");
        String nombre=sc.nextLine();
        try{
            int busca=buscaNombre(nombre); 
            System.out.println("\n" + agenda.get(busca));
            System.out.println("\nNUEVO TELÉFONO? ");
            String tel=sc.nextLine();
            agenda.get(busca).setTelefono(tel);
        }catch (ContactoNoEncontrado e){
            System.out.println(e.getMessage());
        }
    }
    
    private int buscaNombre(String nombre) throws ContactoNoEncontrado {
        int b=-1;int pos=0;
        for (Contacto c:agenda){
            if (c.getNombre().equalsIgnoreCase(nombre)){
                b=pos;
                break;
            }
            pos++;
        }
        if (b==-1){
            throw new ContactoNoEncontrado (nombre + " no está en la Agenda");
        }
        return b;
    }

//<editor-fold defaultstate="collapsed" desc="PERSISTENCIA">
    public void persistirAgenda(){
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Agenda.dat")))
        {
            //oos.writeObject(agenda);
            for (Contacto c:agenda){
                oos.writeObject(c);
            }
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void importarAgenda(){
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Agenda.dat"))){
           
           //agenda = (ArrayList<Contacto>) ois.readObject();
          
           Contacto c;
           while ((c = (Contacto) ois.readObject()) != null) {
              agenda.add(c);
           }
           System.out.println("Copia de seguridad realizada con éxito.");
           
        } catch (ClassNotFoundException e) {
                System.out.println(e.getMessage()); 
        } catch (FileNotFoundException e) {
                 System.out.println(e.getMessage());                                                          
        } catch (IOException e) {
                 System.out.println(e.getMessage());
        }
    }
//</editor-fold>

}