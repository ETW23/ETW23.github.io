public interface Medible
{
    float PI = 3.1416f;   // Por defecto public static  final en una interface
    float area();             // Por defecto public abstract en una interface
    float perimetro();

}
