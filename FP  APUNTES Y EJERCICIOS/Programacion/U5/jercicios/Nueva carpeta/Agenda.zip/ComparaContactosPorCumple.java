 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.educastur.eduardocl.colecciones.agenda;

/**
 *
 * @author edu
 */
import java.util.Comparator;

public class ComparaContactosPorCumple implements Comparator<Contacto> {

    @Override
    public int compare(Contacto c1, Contacto c2) {
        
        return c1.getCumple().compareTo(c2.getCumple());
        /*
        Si no existiera un método compareTo para LocalDate y lo 
        tuviera que hacer manualmente
        int res=0;
        if (c1.getCumple().isBefore(c2.getCumple())){
            res=-1;
        }
        if (c1.getCumple().isAfter(c2.getCumple())){
            res=1;
        }
        return res;*/
    }
}
