/** 
 
 Crear de forma aleatoria usuarios/as de educastur de la siguiente forma: "c4Z5gTy2@educastur.es"

  "8 CARACTERES ALFANUMÉRICOS (Mezcla de Minúsculas|Mayúsculas|números) + @educastur.es"
  * (LOS USUARIOS/AS NO PUEDEN EMPEZAR POR UN NÚMERO)

PARTIMOS de un String con todas las minúsculas, Mayúsculas y números.
Sabemos que podemos acceder a cualquier caracter individual del String con el método charAt(posicion);

Sólo hay que sacar 8 posiciones aleatorias y con esos 8 caracteres crear el usuario educastur:

          8 posiciones aleatorias de charsAlumn (LA 1ª NO PUEDE SER UN NÚMERO) + @educastur.es

Hay que crear tantos usuarios educastur como se nos indique por teclado, almacenarlos en un
Array de Strings y mostrarlos por pantalla.

*/


public class Repaso5{
    public static void main(String[] args) {
        
        String caracteres = new String("abcdefghijklmnñopqrstuvxyzABCDEFGHYJKLMNÑOPQRSTUVXYZ1234567890");
        
           
        
                 
    }
}