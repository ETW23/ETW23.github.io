import java.util.ArrayList; 
public class Prueba {
     public static void main (String [ ] Args) {
          ArrayList <Medible>  figuras = new ArrayList ();
          figuras.add (new Cuadrado (3.5f));
          figuras.add (new Cuadrado (5));
          figuras.add (new Circulo (4));
          figuras.add (new Cuadrado (7));
          figuras.add (new Rectangulo (4 , 8.2f));
          figuras.add (new Rectangulo (6.3f , 3.3f));
          for (Medible m : figuras){
                System.out.println ("Area:  "+ m.area() + "\tPerímetro: " +m.perimetro());
         }
   }
}

