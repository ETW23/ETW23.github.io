
/**  
   
  CON LOS 3 TIPOS de bucles Java que hemos trabajado (for | while | do while)
 
  Hacer un programa que recorre un Array de enteros {3,4,5,1,6,0,8,11,0,2,4,7} y mostrar por pantalla:
  LA SUMA DE LOS PARES DEL ARRAY ES : 
  LA SUMA DE LOS IMPARES DEL ARRAY ES: 
  EL NUMERO DE CEROS QUE HAY ES: 
  
 */

public class Repaso1
{
    public static void main (String[] args)
    {
        int[] numeros = {3,4,5,1,6,0,8,11,0,2,4,7};    
        
        
    }
    
    
}
