import java.awt.*;


public class Triangulo extends Figura
{
    private int altura;
    private int base;
    
    public Triangulo(int xPos, int yPos, String color, int altura, int base)
    {
        super(xPos,yPos,color);
        this.altura=altura;
        this.base=base;
    }       
    
    public void cambiaTamaño(int nuevaAltura, int nuevaBase)
    {
        borrar();
        altura = nuevaAltura;
        base = nuevaBase;
        dibujar();
    }

    @Override
    public void dibujar()
    {
        if(getVisible()) {
            Canvas canvas = Canvas.getCanvas();
            int[] xpoints = { getXPos(),  getXPos() + (base/2),  getXPos() - (base/2) };
            int[] ypoints = { getYPos(), getYPos() + altura, getYPos() + altura };
            canvas.draw(this, getColor(), new Polygon(xpoints, ypoints, 3));
            canvas.wait(10);
        }
    }

}
