/**
     
    Hacer un programa para crear una palabra aleatoria. El tamaño en letras de la palabra se introduce por teclado.
    
    La palabra se formará con 1 consonante + 1 vocal + 1 consonante + 1 vocal ... y así sucesivamente
    
    Ejemplo: palabra de tamaño 10:  "hafanevohi"
    
    hay que escribir la palabra por pantalla, y mostrar además:
     * CUÁL ES LA VOCAL QUE MÁS VECES APARECE en la palabra.(Si hay varias que aparecen el mismo número de veces, basta con mostrar una de ellas)
     * CUÁL ES LA PRIMERA LETRA DE LA PALABRA Y LA ÚLTIMA 
*/


public class Repaso3
{
   public static void main (String[] args)
   {
     
   }
}
